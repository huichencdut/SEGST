function [HF,LF,HF1,LF1]=SEGST_ConstantFreProfile1(signal,fl,fh,dt,lmd,p)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% input��
%%      sig, section matrix
%%      fl,  low frequency value
%%      fh,  high frequency value
%%      dt,  time sampling rate (unit:s)
%%      lmd and p, the parameters for SEGST
%% output��
%%      HF, high frequency section
%%      LF, low frequency section
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

LF=[];HF=[];LF1=[];HF1=[];

[N,n]=size(signal);
f=(0:N/2-1)/(dt*N);
e_l=abs(f-fl);         
e_h=abs(f-fh);
nl=find(e_l==min(abs(f-fl)));       
nh=find(e_h==min(abs(f-fh)));

L=1:n; m=100; 
for i=1:n 
    if L(i)==m
        disp (i)
        m=m + 100;
    else
        m=m + 0;
    end
    [seo,Te,stfr,t0,f0] = SEGST(signal(:,i),'lmd',lmd,'p',p);    
    
    LF = [LF Te(nl,:)'];                     
    HF = [HF Te(nh,:)'];                     
    LF = abs(LF);
    HF = abs(HF);
    
    LF1 = [LF1 stfr(nl,:)'];                    
    HF1 = [HF1 stfr(nh,:)'];                     
    LF1 = abs(LF1);
    HF1 = abs(HF1);
end