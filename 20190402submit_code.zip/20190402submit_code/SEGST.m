function [IF,Te,tfr,t,f] = SEGST(sig,varargin)
%   Synchroextracting Generalize S-Transform
%	sig       : Signal.   (column vector)
%	varargin : parameters
%                 'minfreq', 'maxfreq': frequency range [minfreq maxfreq]
%                 in time-frequency spectra, default[0, fix(length(sig)/2)]
%                 'samplingrate'      : default 1
%                 'freqsamplingrate'  : default 1
%                 'lmd'               : default 1
%                 'p'                 : default 1
%   IF   : Synchroextracting operator representation.
%   Te   : SEGST result.
%   tfr  : GST result
%   t    : time
%   f    : frequency


% Change to column vector
if size(sig,2) > size(sig,1)
	sig=sig';	
end
% Make sure it is a 1-dimensional array
if size(sig,2) > 1
   error('Please enter a *vector* of data, not matrix')
elseif size(sig)==1
	error('Please enter a *vector* of data, not a scalar')
end

N = length(sig);
opt = check_input(N,varargin{:});

t = (0:N-1)*opt.samplingrate;
spe_nelements =ceil((opt.maxfreq - opt.minfreq+1)/opt.freqsamplingrate);
f = (opt.minfreq + (0:spe_nelements-1)*opt.freqsamplingrate)/(opt.samplingrate*N);

[tfr,dtfr] = setstrans(sig,opt); 
IF = SEO(tfr,dtfr);
Te = SET(tfr,IF);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Te = SET(tfr,IF)

Te = tfr.*IF;

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function IF = SEO(tfr,dtfr)

IF = abs(abs(real(dtfr./tfr))<0.5);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tfr,dtfr] = setstrans(sig,opt) 

n = length(sig);
sig_fft = fft(sig);
sig_fft = [sig_fft sig_fft] ;

minfreq = opt.minfreq;
maxfreq = opt.maxfreq;
freqsamplingrate = opt.freqsamplingrate;
tfr=zeros(ceil((maxfreq - minfreq+1)/freqsamplingrate),n);
dtfr=zeros(ceil((maxfreq - minfreq+1)/freqsamplingrate),n);
% Compute the mean
% Compute S-transform value for 1 ... ceil(n/2+1)-1 frequency points
fa = 1:n;
if minfreq == 0
    tfr(1,:) = mean(sig);
    dtfr(1,:) = minfreq;
else
    [gauss,dgauss] = g_window(n,minfreq,opt);
  	tfr(1,:)=ifft( sig_fft(minfreq+fa).*gauss );
    dtfr(1,:)=ifft( sig_fft(minfreq+fa).*dgauss );
end

%the actual calculation of the ST
% Start loop to increment the frequency point
for banana=freqsamplingrate:freqsamplingrate:(maxfreq-minfreq)
   [gauss,dgauss] = g_window(n,minfreq+banana,opt);
   tfr(banana/freqsamplingrate+1,:)=ifft(sig_fft( minfreq+banana+fa ).*gauss );
   dtfr(banana/freqsamplingrate+1,:)=ifft(sig_fft( minfreq+banana+fa ).*dgauss );
end   % a loop!  

tfr(abs(tfr)<1e-2) = 0;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [gauss,dgauss]=g_window(length,freq,opt)

% Function to compute the Gaussion window for 
% function Stransform. g_window is used by function
% Stransform. Programmed by Eric Tittley
lmd = opt.lmd ;
p = opt.p ;
vector(1,:)=0:length-1;
vector(2,:)=-length:-1;
vector1=vector.^2;    
vector1=vector1*( -2*pi^2/( lmd*lmd*freq^(2*p) ) );
% Compute the Gaussion window
gauss=sum(exp(vector1));
dgauss=sum(exp(vector1).*vector);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function opt = check_input(N,varargin)

%  initialization
minfreq = 0;
maxfreq = fix(N/2);
samplingrate = 1;
freqsamplingrate = 1;
lmd = 1 ;
p = 1 ;

% Initialized using the input values
if nargin>1
    for vn = 1:2:nargin-1
        copt=varargin{vn};
        if strcmpi(copt,'minfreq'), if ~isempty(varargin{vn+1}) && isnumeric(varargin{vn+1}), minfreq=varargin{vn+1}; end
        elseif strcmpi(copt,'maxfreq'), if ~isempty(varargin{vn+1}) && isnumeric(varargin{vn+1}), maxfreq=varargin{vn+1}; end
        elseif strcmpi(copt,'samplingrate'), if ~isempty(varargin{vn+1}) && isnumeric(varargin{vn+1}), samplingrate=varargin{vn+1}; end
        elseif strcmpi(copt,'freqsamplingrate'), if ~isempty(varargin{vn+1}) && isnumeric(varargin{vn+1}), freqsamplingrate=varargin{vn+1};end
		elseif strcmpi(copt,'lmd'), if ~isempty(varargin{vn+1}) && isnumeric(varargin{vn+1}), lmd=varargin{vn+1}; end
		elseif strcmpi(copt,'p'), if ~isempty(varargin{vn+1}) && isnumeric(varargin{vn+1}), p=varargin{vn+1}; end
        else error(['There is no Property ''',varargin{vn},'''']);
        end
    end
end

% check or alter input 
if minfreq < 0 || minfreq > fix(N/2);  minfreq = 0; end
if maxfreq > fix(N/2)  || maxfreq < 0;  maxfreq = fix(N/2); end
if minfreq > maxfreq
    temporary = minfreq;
    minfreq = maxfreq;
    maxfreq = temporary;
    clear temporary;
end
if samplingrate <0;  samplingrate = abs(samplingrate);end
if freqsamplingrate < 0; freqsamplingrate = abs(freqsamplingrate);end

% display input
fprintf('minfreq = %d\n',minfreq);
fprintf('maxfreq = %d\n',maxfreq);
fprintf('samplingrate = %d\n',samplingrate);
fprintf('freqsamplingrate = %d\n',freqsamplingrate);
fprintf('lmd = %d\n',lmd);
fprintf('p = %d\n',p);
disp(' ');

% Output in opt
opt = struct();
opt.minfreq = minfreq;
opt.maxfreq = maxfreq;
opt.samplingrate = samplingrate;
opt.freqsamplingrate = freqsamplingrate;
opt.lmd = lmd;
opt.p = p;

end