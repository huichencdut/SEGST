%% Fig.5-Fig.6

clc;clear;close all;

%% signal parameters set
SampleFre = 1000;
N=1000;
t =(1:N)./SampleFre; 

%% ricker wavelet parameters set
fm=30;
t1=(-N/2:N/2)/SampleFre;
ricker=(1-2*(pi*fm*t1).^2).*exp(-(pi*fm*t1).^2);

%% generate refelect coeffs
R1=zeros(1,1000);
R1(160)=0.35;R1(340)=-0.25;
R1(800)=0.4;R1(581)=0.15;R1(630)=-0.15;

%% obtain the synthetic signal by convolution of reflection coeffs and ricker wavelet
sig=conv2(R1,ricker,'same');

%% plot the synthetic signal
figure;plot(t,sig,'linewidth',1.5);
set(gca,'FontSize',14);xlabel('Time (s)');ylabel('Amplitude')
set(gcf, 'color', [1 1 1]) 
pos=get(gcf,'position');
set(gcf, 'position', [pos(1)-300 pos(2)-200 pos(3)+150 pos(4)+50])
text(-0.14,0.4,'(b)', 'Color', 'k', 'FontSize', 16)


%% plot the reflection coeffs
figure;plot(t,R1,'linewidth',1.5);xlabel('Time (s)');ylabel('Amplitude'); set(gca,'FontSize',14);
set(gcf, 'color', [1 1 1]) 
set(gcf, 'position', [pos(1)-300 pos(2)-200 pos(3)+150 pos(4)+50])
text(-0.14,0.4,'(a)', 'Color', 'k', 'FontSize', 16)


f = SampleFre/N:SampleFre/N:SampleFre/2; 

%% process signal by using SET
[IF,Te,tfr] = SET_Y(sig',120);

%% show the result of STFT
figure;imagesc(t,f,abs(tfr)/max(max(abs(tfr))));
axis xy;set(gca,'FontSize',16);xlabel('Time (s)');ylabel('Frequency (Hz)');ylim([0 200]);
colormap jet;colorbar;shading interp;
set(gcf, 'color', [1 1 1]) 

pos=get(gcf,'position');
set(gcf, 'position', [pos(1)-300 pos(2)-200 pos(3)+150 pos(4)+50])
text(-0.16,200,'(a)', 'Color', 'k', 'FontSize', 16)

%% show the result of SET
figure;imagesc(t,f,abs(Te)/max(max(abs(Te))));
axis xy;set(gca,'FontSize',16);xlabel('Time (s)');ylabel('Frequency (Hz)');ylim([0 200]);
colormap jet;colorbar;shading interp;
set(gcf, 'color', [1 1 1]) 
set(gcf, 'position', [pos(1)-300 pos(2)-200 pos(3)+150 pos(4)+50])
text(-0.16,200,'(b)', 'Color', 'k', 'FontSize', 16)
% title('set');

%% process signal by using SEGST
[IF,Te,tfr,t0,f0] = SEGST(sig,'lmd',11,'p',0.7);

%% show the result of GST
figure;imagesc(t,f, abs(tfr)/max(max(abs(tfr))));  
axis xy;xlabel('Time (s)');ylabel('Frequency (Hz)');ylim([0 200]);
colormap jet;colorbar;set(gca,'FontSize',16);shading interp;
set(gcf, 'color', [1 1 1]) 
set(gcf, 'position', [pos(1)-300 pos(2)-200 pos(3)+150 pos(4)+50])
text(-0.16,200,'(c)', 'Color', 'k', 'FontSize', 16)

%% show the result of SEGST
figure;imagesc(t,f, abs(Te)/max(max(abs(Te))));
axis xy;set(gca,'FontSize',16);xlabel('Time (s)');ylabel('Frequency (Hz)');ylim([0 200]);
colormap jet;colorbar;shading interp;
set(gcf, 'color', [1 1 1]) 
set(gcf, 'position', [pos(1)-300 pos(2)-200 pos(3)+150 pos(4)+50])
text(-0.16,200,'(d)', 'Color', 'k', 'FontSize', 16)