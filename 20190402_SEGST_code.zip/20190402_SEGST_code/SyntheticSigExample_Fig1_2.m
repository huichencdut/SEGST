%% Fig.1-Fig.2
clc; clear;close all;

SampleFre = 1000 ;
N=1000;
t =(1:N)./SampleFre;   
f=(SampleFre/N).*(0:N-1)/2;

sig1 = 0.6*cos(2*pi*140*t);
sig2 = 0.6*(1+0.3.*cos(2*t)).*exp(-t/20).*cos(20*pi*(8*t+6*t.^1.8+0.3*sin(t)));
sig3 = (2+0.2.*cos(t)).*cos(180*pi*(3*t+0.1*cos(6.4*t)));
sig =sig1+sig2+sig3;

%% plot the signal
figure;
subplot(411);plot(t,sig1);ylabel('s_1');set(gca,'FontSize',14);
subplot(412);plot(t,sig2);ylabel('s_2');set(gca,'FontSize',14);
subplot(413);plot(t,sig3);ylabel('s_3');set(gca,'FontSize',14);
subplot(414);plot(t,sig);ylabel('s');set(gca,'FontSize',14);xlabel('Time (s)');
set(gcf, 'color', [1 1 1]) 

%% process signal by using SET
[IF,Te,tfr] = SET_Y(sig');

%% show the result of STFT
figure;imagesc(t,f,abs(tfr)/max(max(abs(tfr))));
axis xy;set(gca,'FontSize',14);xlabel('Time (s)');ylabel('Frequency (Hz)');  
colormap jet;colorbar;shading interp;
set(gcf, 'color', [1 1 1]) 
pos=get(gcf,'position');
set(gcf, 'position', [pos(1)-300 pos(2)-300 pos(3)+100 pos(4)+100])
text(-0.16,500,'(a)', 'Color', 'k', 'FontSize', 16)

%% show the result of SET
figure;imagesc(t,f,abs(Te)/max(max(abs(Te))));
axis xy;set(gca,'FontSize',14);xlabel('Time (s)');ylabel('Frequency (Hz)');  
colormap jet;colorbar;shading interp;
set(gcf, 'color', [1 1 1]) 
set(gcf, 'position', [pos(1)-300 pos(2)-300 pos(3)+100 pos(4)+100])
text(-0.16,500,'(b)', 'Color', 'k', 'FontSize', 16)


%% process signal by using SEGST
[IF,Te1,tfr1,t0,f0] = SEGST(sig,'lmd',5,'p',0.4);

%% show the result of GST
tfr1 = tfr1(1:500,:);
Te1 = Te1(1:500,:);
figure;imagesc(t,f, abs(tfr1)/max(max(abs(tfr1))));  
axis xy;set(gca,'FontSize',14);xlabel('Time (s)');ylabel('Frequency (Hz)');   
colormap jet;colorbar;shading interp;
set(gcf, 'color', [1 1 1]) 
set(gcf, 'position', [pos(1)-300 pos(2)-300 pos(3)+100 pos(4)+100])
text(-0.16,500,'(c)', 'Color', 'k', 'FontSize', 16)

%% show the result of SEGST
figure;imagesc(t,f, abs(Te1)/max(max(abs(Te1))));
axis xy;set(gca,'FontSize',14);xlabel('Time (s)');ylabel('Frequency (Hz)');  
colormap jet;colorbar;shading interp;
set(gcf, 'color', [1 1 1]) 
set(gcf, 'position', [500 500 100 100])
set(gcf, 'position', [pos(1)-300 pos(2)-300 pos(3)+100 pos(4)+100])
text(-0.16,500,'(d)', 'Color', 'k', 'FontSize', 16)
