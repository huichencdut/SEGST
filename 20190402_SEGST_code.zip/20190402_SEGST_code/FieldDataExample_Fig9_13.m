%% Fig.9-Fig.13

clc;clear;close all;

%% load field data
fid = fopen('InLineJS33.sgy') ;
LayerSec = fread(fid,[1126 304],'float32') ;
fclose(fid) ;

%% Fig.9 is showed by a seismic software. 


%% load seismic horizon
load('inlinetop4.mat');
dt1 = 0.001 ;
inlinetop4 = inlinetop4*dt1 ;

[sample,trace] = size(LayerSec) ;
dt = 0.002 ; Time = (0:sample-1)*dt; Trace = 1:trace;

%% get the constant frequency sections of SET
f1 = 40.17;
f2 = 50.17;
[HF,LF,HF0,LF0]=SET_Y_ConstantFreProfile(LayerSec,dt,f1,f2);

%% smoothing the result of SET
for i=1:size(HF,1)
     HF1(i,:)=smooth(HF(i,:),8);  
 end 

 for i=1:size(HF,2)
     HighFrequency_SET(:,i)=smooth(HF1(:,i),8);  
 end
 
 for i=1:size(LF,1)
     LF1(i,:)=smooth(LF(i,:),8);  
 end 

 for i=1:size(LF,2)
     LowFrequency_SET(:,i)=smooth(LF1(:,i),8);  
 end
 
%% show the constant frequency sections of SET
figure;imagesc(Trace,Time,HighFrequency_SET);
set(gca,'FontSize',14);xlabel('Trace Number');ylabel('Time (s)');
colormap jet;
set(gcf, 'color', [1 1 1]) 
hold on
plot(Trace,inlinetop4,'m', 'LineWidth', 1.5);
plot([117,117],[1.2,1.4], 'm', 'LineWidth', 1.5);  
hold off
xlim([80 220]);ylim([1.2 1.9]); 
caxis([0,8000]);colorbar;
text(57,1.18,'(b)', 'Color', 'k', 'FontSize', 16)

figure;imagesc(Trace,Time,LowFrequency_SET);
set(gca,'FontSize',14);xlabel('Trace Number');ylabel('Time (s)');
colormap jet;
set(gcf, 'color', [1 1 1]) 
hold on
plot(Trace,inlinetop4,'m', 'LineWidth', 1.5);
plot([117,117],[1.2,1.4], 'm', 'LineWidth', 1.5);  
hold off
xlim([80 220]);ylim([1.2 1.9]); 
caxis([0,8000]);colorbar;
text(57,1.18,'(a)', 'Color', 'k', 'FontSize', 16)


%% smoothing the result of STFT

for i=1:size(HF0,1)
     HF1(i,:)=smooth(HF0(i,:),8);  
 end 

 for i=1:size(HF0,2)
     HighFrequency_STFT(:,i)=smooth(HF1(:,i),8);  
 end
 
for i=1:size(LF0,1)
     LF1(i,:)=smooth(LF0(i,:),8);  
 end 

 for i=1:size(LF0,2)
     LowFrequency_STFT(:,i)=smooth(LF1(:,i),8);  
 end

%% show the constant frequency sections of STFT
figure;imagesc(Trace,Time,HighFrequency_STFT);
set(gca,'FontSize',14);xlabel('Trace Number');ylabel('Time (s)');
colormap jet;
set(gcf, 'color', [1 1 1]) 
hold on
plot(Trace,inlinetop4,'m', 'LineWidth', 1.5);
plot([117,117],[1.2,1.4], 'm', 'LineWidth', 1.5);  
hold off
xlim([80 220]);ylim([1.2 1.9]); 
caxis([0,14000]);colorbar;
text(57,1.18,'(b)', 'Color', 'k', 'FontSize', 16)

figure;imagesc(Trace,Time,LowFrequency_STFT);
set(gca,'FontSize',14);xlabel('Trace Number');ylabel('Time (s)');
colormap jet;
set(gcf, 'color', [1 1 1]) 
hold on
plot(Trace,inlinetop4,'m', 'LineWidth', 1.5);
plot([117,117],[1.2,1.4], 'm', 'LineWidth', 1.5);  
hold off
xlim([80 220]);ylim([1.2 1.9]); 
caxis([0,14000]);colorbar;
text(57,1.18,'(a)', 'Color', 'k', 'FontSize', 16)




%% get the constant frequency sections of SEGST

[HF,LF,HF0,LF0]=SEGST_ConstantFreProfile1(LayerSec,f1,f2,dt,2.4,0.8);

%% smoothing the result of SEGST
for i=1:size(HF,1)
     HF1(i,:)=smooth(HF(i,:),8);  
end

for i=1:size(HF,2)
    HighFrequency_SEGST(:,i)=smooth(HF1(:,i),8);  
end
 
 for i=1:size(LF,1)
     LF1(i,:)=smooth(LF(i,:),8);  
 end

 for i=1:size(LF,2)
     LowFrequency_SEGST(:,i)=smooth(LF1(:,i),8);  
 end

%% show the constant frequency sections of SEGST
figure;imagesc(Trace,Time,HighFrequency_SEGST);
set(gca,'FontSize',14);xlabel('Trace Number');ylabel('Time (s)');
colormap jet;
set(gcf, 'color', [1 1 1]) 
hold on
plot(Trace,inlinetop4,'m', 'LineWidth', 1.5);
plot([117,117],[1.2,1.4], 'm', 'LineWidth', 1.5);  
hold off
xlim([80 220]);ylim([1.2 1.9]); 
caxis([0,3500]);colorbar;
text(57,1.18,'(b)', 'Color', 'k', 'FontSize', 16)

figure;imagesc(Trace,Time,LowFrequency_SEGST);
set(gca,'FontSize',14);xlabel('Trace Number');ylabel('Time (s)');
colormap jet;
set(gcf, 'color', [1 1 1]) 
hold on
plot(Trace,inlinetop4,'m', 'LineWidth', 1.5);
plot([117,117],[1.2,1.4], 'm', 'LineWidth', 1.5);  
hold off
xlim([80 220]);ylim([1.2 1.9]); 
caxis([0,3500]);colorbar;
text(57,1.18,'(a)', 'Color', 'k', 'FontSize', 16)


%% smoothing the result of GST
for i=1:size(HF0,1)
     HF1(i,:)=smooth(HF0(i,:),8);  
 end 

 for i=1:size(HF0,2)
     HighFrequency_GST(:,i)=smooth(HF1(:,i),8);  
 end
 
for i=1:size(LF0,1)
     LF1(i,:)=smooth(LF0(i,:),8);  
 end 

 for i=1:size(LF0,2)
     LowFrequency_GST(:,i)=smooth(LF1(:,i),8);  
 end

%% show the constant frequency sections of GST
figure;imagesc(Trace,Time,HighFrequency_GST);
set(gca,'FontSize',14);xlabel('Trace Number');ylabel('Time (s)');
colormap jet;
set(gcf, 'color', [1 1 1]) 
hold on
plot(Trace,inlinetop4,'m', 'LineWidth', 1.5);
plot([117,117],[1.2,1.4], 'm', 'LineWidth', 1.5);  
hold off
xlim([80 220]);ylim([1.2 1.9]); 
caxis([0,10000]);colorbar;
text(57,1.18,'(b)', 'Color', 'k', 'FontSize', 16)


figure;imagesc(Trace,Time,LowFrequency_GST);
set(gca,'FontSize',14);xlabel('Trace Number');ylabel('Time (s)');
colormap jet;
set(gcf, 'color', [1 1 1]) 
hold on
plot(Trace,inlinetop4,'m', 'LineWidth', 1.5);
plot([117,117],[1.2,1.4], 'm', 'LineWidth', 1.5);  
hold off
xlim([80 220]);ylim([1.2 1.9]); 
caxis([0,10000]);colorbar;
text(57,1.18,'(a)', 'Color', 'k', 'FontSize', 16)